/**
 * Represents a rectangular area on the game board.
 * 
 * @version 1.0 2026-1
 */
public class Rectangle {
    private double x;
    private double y;
    private double height;
    private double broad;

    /**
     * Creates a rectangle with the given position and dimensions.
     */
    public Rectangle(double x, double y, double height, double broad) {
        this.x = x;
        this.y = y;
        this.height = height;
        this.broad = broad;
    }

    public double getX() { return x; }
    public double getY() { return y; }
    public double getHeight() { return height; }
    public double getBroad() { return broad; }

    /**
     * Returns true if the point (px, py) is inside this rectangle.
     */
    public boolean contains(double px, double py) {
        return px >= x && px <= x + broad && py >= y && py <= y + height;
    }
}