/**
 * Represents the game board grid with safe zones.
 * 
 * @version 1.0 2026-1
 */
public class Table {
    private int rows;
    private int cols;
    private Rectangle meta;

    /**
     * Creates the game table with the given dimensions and safe zone.
     */
    public Table(int rows, int cols, Rectangle meta) {
        this.rows = rows;
        this.cols = cols;
        this.meta = meta;
    }

    public int getRows() { return rows; }
    public int getCols() { return cols; }
    public Rectangle getMeta() { return meta; }

    /**
     * Returns true if the position (x, y) is inside the safe zone.
     */
    public boolean zonaSegura(int x, int y) {
        return meta.contains(x, y);
    }
}