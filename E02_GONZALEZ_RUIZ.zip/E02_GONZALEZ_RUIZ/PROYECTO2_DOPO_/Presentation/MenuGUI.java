package Presentation;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * Main menu screen of The World's Hardest Game.
 * 
 * @author Gonzalez-Ruiz
 * @version 1.0 2026-1
 */
public class MenuGUI extends JFrame {

    private JLabel title;
    private JButton playButton;
    private JButton exitButton;

    /**
     * Creates and displays the main menu.
     */
    public MenuGUI() {
        setTitle("The World's Hardest Game");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        title = new JLabel("THE WORLD'S HARDEST GAME", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 18));
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        add(title, gbc);

        playButton = new JButton("PLAY");
        playButton.setPreferredSize(new Dimension(120, 35));
        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 1;
        add(playButton, gbc);

        exitButton = new JButton("EXIT");
        exitButton.setPreferredSize(new Dimension(120, 35));
        gbc.gridx = 0; gbc.gridy = 2;
        add(exitButton, gbc);

        playButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                showModeSelection();
            }
        });

        exitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        setVisible(true);
    }

    /**
     * Opens the game mode selection screen.
     */
    private void showModeSelection() {
        dispose();
        new ModeSelectionGUI();
    }
}