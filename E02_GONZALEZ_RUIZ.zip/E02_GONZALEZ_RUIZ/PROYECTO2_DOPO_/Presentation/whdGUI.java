package Presentation;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * Main game screen. Displays the board, player, enemies and coins.
 * 
 * @author Gonzalez-Ruiz
 * @version 1.0 2026-1
 */
public class whdGUI extends JFrame implements KeyListener {

    private static final int CELL_SIZE = 40;
    private static final int COLS = 15;
    private static final int ROWS = 10;

    // Player position
    private int playerX;
    private int playerY;
    private int deaths;
    private int coinsCollected;

    // Safe zones (in cells)
    private int safeZoneStartX;
    private int safeZoneEndX;
    private int safeZoneEndCol;

    // Coins: [x, y, collected]
    private int[][] coins;

    // Enemy: [x, y, dx, dy]
    private int[][] enemies;

    private JLabel hud;
    private GamePanel gamePanel;
    private Timer gameTimer;

    /**
     * Creates and displays the main game screen.
     */
    public whdGUI() {
        setTitle("The World's Hardest Game");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        setResizable(false);

        deaths = 0;
        coinsCollected = 0;
        playerX = 1;
        playerY = ROWS / 2;

        // Safe zone columns
        safeZoneStartX = 0;
        safeZoneEndCol = COLS - 1;

        // 5 coins in the middle area
        coins = new int[][] {
            {5, 3, 0}, {7, 5, 0}, {9, 3, 0}, {6, 7, 0}, {8, 6, 0}
        };

        // 2 basic enemies: [x, y, dx, dy]
        enemies = new int[][] {
            {6, 2, 1, 0},
            {10, 5, 0, 1}
        };

        hud = new JLabel("  NIVEL: 1    Muertes: 0    Coins: 0/5");
        hud.setFont(new Font("Arial", Font.BOLD, 14));
        hud.setBackground(Color.LIGHT_GRAY);
        hud.setOpaque(true);
        add(hud, BorderLayout.NORTH);

        gamePanel = new GamePanel();
        add(gamePanel, BorderLayout.CENTER);

        pack();
        setLocationRelativeTo(null);
        addKeyListener(this);
        setFocusable(true);
        setVisible(true);

        // Game loop: moves enemies every 300ms
        gameTimer = new Timer(300, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                moveEnemies();
                checkCollisions();
                gamePanel.repaint();
            }
        });
        gameTimer.start();
    }

    /**
     * Moves all enemies and bounces them off walls.
     */
    private void moveEnemies() {
        for (int[] enemy : enemies) {
            enemy[0] += enemy[2];
            enemy[1] += enemy[3];
            if (enemy[0] <= 1 || enemy[0] >= COLS - 2) enemy[2] *= -1;
            if (enemy[1] <= 0 || enemy[1] >= ROWS - 1) enemy[3] *= -1;
        }
    }

    /**
     * Checks collisions between player, coins and enemies.
     */
    private void checkCollisions() {
        // Coin collection
        for (int[] coin : coins) {
            if (coin[2] == 0 && coin[0] == playerX && coin[1] == playerY) {
                coin[2] = 1;
                coinsCollected++;
                updateHUD();
            }
        }

        // Enemy collision → death
        for (int[] enemy : enemies) {
            if (enemy[0] == playerX && enemy[1] == playerY) {
                deaths++;
                playerX = 1;
                playerY = ROWS / 2;
                updateHUD();
            }
        }

        // Win condition
        if (coinsCollected == coins.length && playerX == COLS - 1) {
            gameTimer.stop();
            int option = JOptionPane.showOptionDialog(
                this,
                "¡Felicidades!",
                "Victoria",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                null,
                new String[]{"Sig. Nivel", "Exit"},
                "Sig. Nivel"
            );
            if (option == 1) System.exit(0);
        }
    }

    /**
     * Updates the HUD label with current game state.
     */
    private void updateHUD() {
        hud.setText("  NIVEL: 1    Muertes: " + deaths + "    Coins: " + coinsCollected + "/" + coins.length);
    }

    public void keyPressed(KeyEvent e) {
        int key = e.getKeyCode();
        int nx = playerX;
        int ny = playerY;

        if (key == KeyEvent.VK_UP    || key == KeyEvent.VK_W) ny--;
        if (key == KeyEvent.VK_DOWN  || key == KeyEvent.VK_S) ny++;
        if (key == KeyEvent.VK_LEFT  || key == KeyEvent.VK_A) nx--;
        if (key == KeyEvent.VK_RIGHT || key == KeyEvent.VK_D) nx++;

        if (nx >= 0 && nx < COLS && ny >= 0 && ny < ROWS) {
            playerX = nx;
            playerY = ny;
        }

        checkCollisions();
        gamePanel.repaint();
    }

    public void keyReleased(KeyEvent e) {}
    public void keyTyped(KeyEvent e) {}

    /**
     * Inner panel that draws the game board.
     */
    private class GamePanel extends JPanel {

        public GamePanel() {
            setPreferredSize(new Dimension(COLS * CELL_SIZE, ROWS * CELL_SIZE));
        }

        public void paintComponent(Graphics g) {
            super.paintComponent(g);

            // Draw grid
            g.setColor(Color.WHITE);
            g.fillRect(0, 0, COLS * CELL_SIZE, ROWS * CELL_SIZE);
            g.setColor(Color.LIGHT_GRAY);
            for (int i = 0; i < COLS; i++)
                for (int j = 0; j < ROWS; j++)
                    g.drawRect(i * CELL_SIZE, j * CELL_SIZE, CELL_SIZE, CELL_SIZE);

            // Draw start safe zone (green)
            g.setColor(new Color(144, 238, 144));
            g.fillRect(0, 0, CELL_SIZE, ROWS * CELL_SIZE);

            // Draw end safe zone (green)
            g.setColor(new Color(144, 238, 144));
            g.fillRect((COLS - 1) * CELL_SIZE, 0, CELL_SIZE, ROWS * CELL_SIZE);

            // Draw coins (yellow circles)
            g.setColor(Color.YELLOW);
            for (int[] coin : coins) {
                if (coin[2] == 0) {
                    int cx = coin[0] * CELL_SIZE + CELL_SIZE / 4;
                    int cy = coin[1] * CELL_SIZE + CELL_SIZE / 4;
                    g.fillOval(cx, cy, CELL_SIZE / 2, CELL_SIZE / 2);
                }
            }

            // Draw enemies (blue circles)
            g.setColor(Color.BLUE);
            for (int[] enemy : enemies) {
                int ex = enemy[0] * CELL_SIZE + CELL_SIZE / 4;
                int ey = enemy[1] * CELL_SIZE + CELL_SIZE / 4;
                g.fillOval(ex, ey, CELL_SIZE / 2, CELL_SIZE / 2);
            }

            // Draw player (red square)
            g.setColor(Color.RED);
            g.fillRect(playerX * CELL_SIZE + 5, playerY * CELL_SIZE + 5,
                       CELL_SIZE - 10, CELL_SIZE - 10);
        }
    }
}