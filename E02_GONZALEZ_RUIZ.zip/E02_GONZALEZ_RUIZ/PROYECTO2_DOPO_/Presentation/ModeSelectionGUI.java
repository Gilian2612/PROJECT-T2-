package Presentation;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * Game mode selection screen.
 * 
 * @author Gonzalez-Ruiz
 * @version 1.0 2026-1
 */
public class ModeSelectionGUI extends JFrame {

    private JLabel title;
    private JButton onePlayerButton;
    private JButton twoPlayersButton;

    /**
     * Creates and displays the mode selection screen.
     */
    public ModeSelectionGUI() {
        setTitle("The World's Hardest Game");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        title = new JLabel("THE WORLD'S HARDEST GAME", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 18));
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        add(title, gbc);

        onePlayerButton = new JButton("1 Jugador");
        onePlayerButton.setPreferredSize(new Dimension(150, 35));
        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 1;
        add(onePlayerButton, gbc);

        twoPlayersButton = new JButton("2 Jugadores");
        twoPlayersButton.setPreferredSize(new Dimension(150, 35));
        gbc.gridx = 0; gbc.gridy = 2;
        add(twoPlayersButton, gbc);

        onePlayerButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                startGame();
            }
        });

        twoPlayersButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Modo 2 jugadores disponible en Versión 2.");
            }
        });

        setVisible(true);
    }

    /**
     * Starts the game in single player mode.
     */
    private void startGame() {
        dispose();
        new whdGUI();
    }
}